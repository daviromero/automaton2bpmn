# Automaton2bpmn 
Automaton2bpmn is a library for converting automata (teocomp package) to bpmn.